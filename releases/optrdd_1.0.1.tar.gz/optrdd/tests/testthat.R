library(testthat)
library(optrdd)

test_check("optrdd")
